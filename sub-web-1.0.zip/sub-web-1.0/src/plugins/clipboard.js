import Vue from 'vue'
import clipboard from 'vue-clipboard2'

Vue.use(clipboard)
